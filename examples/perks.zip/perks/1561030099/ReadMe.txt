﻿Contains a pile of modified abilities.

by Set:
Bullet Arts: for guns. series of special shots and passives that boost them.
Melee: for melee weapons
PsiAmp: designed to be used with psiamps
PsiShard: designed for PZ's Psionic Melee. some abilitys will also work with Templar Gauntlets or other melee weapons.
Trickshot: designed for guns.
Unspecific: abilities that don't need to be assigned to a weapon.

